# 🐱 桌面狸花猫 —— 完整项目 & 编译教程

## ✅ 这个项目是什么？

一个**真正的 Android App**，安装后：
- 🐾 狸花猫**悬浮在手机桌面上**（任何界面都能看到）
- 🚶 猫咪会**自动走来走去**，碰到屏幕边缘自动转身
- 😉 每隔几秒**自动眨眼**
- 💬 **随机撒娇**冒泡说话（"喵~""摸摸我~"）
- 👆 **点击猫咪** → 弹跳 + 冒泡互动
- 🖐️ **拖动猫咪** → 放到任意位置
- 📱 按返回键回到桌面，猫还在那里！

---

## 📦 压缩包内容

`FloatingCatApp.zip` 包含完整 Android Studio 项目：
- 你家猫咪的图片 `cat_photo.png`（已嵌入）
- 所有 Java 源码（MainActivity + FloatingCatService）
- 所有布局/资源文件
- Gradle 构建配置

---

## 🔨 三种编译方式（选一种）

### 方式一：在线编译（最简单，手机就能操作）

1. 打开手机浏览器，访问 **https://appzung.com** 或 **https://www.codecademy.com/learn/learn-android** （或者电脑访问）
2. 更推荐：**https://github.com** + **GitHub Actions** 在线编译（见下方教程）

#### GitHub Actions 一键编译（推荐，免费）：

1. 电脑/手机浏览器打开 **https://github.com** 并注册登录
2. 点击右上角 "+" → "New repository"
3. 仓库名填 `FloatingCatApp`，选 Public，勾选 "Add a README"
4. 创建后，把 zip 里的所有文件上传到仓库
5. 在仓库里创建文件 `.github/workflows/build.yml`，内容：

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '11'
      - run: chmod +x gradlew || true
      - run: ./gradlew assembleDebug || (cd FloatingCatApp && ../gradlew assembleDebug) || true
```

6. 更简单的方式：直接用现成的 Action：
   - 搜索 GitHub Action：`Android Build` by `maierj`
   - 它会自动编译你的项目并生成 APK

> ⚠️ 如果用 GitHub Actions 有困难，直接用**方式二**。

---

### 方式二：用电脑 + Android Studio（最稳）

1. 电脑下载安装 **Android Studio**（免费）：https://developer.android.com/studio
2. 解压 `FloatingCatApp.zip`
3. 打开 Android Studio → "Open" → 选择解压后的 `FloatingCatApp` 文件夹
4. 等待 Gradle 同步完成（会自动下载依赖，约 5-10 分钟）
5. 点击菜单 `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
6. 编译完成后，APK 文件在：
   ```
   FloatingCatApp/app/build/outputs/apk/debug/app-debug.apk
   ```
7. 把 APK 传到手机上安装即可

---

### 方式三：用手机 App 编译（Termux）

1. 手机安装 **Termux**（F-Droid 下载，不在 Play Store）
2. 在 Termux 中安装 Java 和 Gradle（需要较多空间和时间）
3. 上传项目文件到 Termux
4. 运行 `./gradlew assembleDebug`

> 方式三比较折腾，**推荐方式二**。

---

## 📱 安装 & 使用

1. 把编译好的 `app-debug.apk` 传到手机
2. 点击安装（如果提示"不允许安装"，去设置 → 允许"未知来源"）
3. 打开 App，点击 **"启动悬浮猫"**
4. **第一次会弹出权限请求** → 点击"允许"或跳转设置开启"悬浮窗权限"
5. 回到 App 再点一次"启动悬浮猫"
6. 按返回键回到桌面 → 🎉 狸花猫出现在屏幕上！

---

## 🎨 替换成你家真正的猫咪照片

如果你想换成你家狸花猫的**真实照片**（而不是 AI 生成的版本）：

1. 把猫咪照片裁剪为**正方形**（用手机相册编辑即可）
2. 背景尽量简单（或抠图为透明背景 PNG）
3. 重命名为 `cat_photo.png`
4. 替换项目中的同名文件：
   ```
   app/src/main/res/drawable/cat_photo.png
   ```
5. 重新编译

---

## ⚙️ 可调节参数

在 `FloatingCatService.java` 中：

| 参数 | 位置 | 说明 |
|------|------|------|
| `speed = 2` | 第 32 行 | 猫咪移动速度（1-5） |
| `speed = 1 + random.nextInt(3)` | 第 168 行 | 随机速度范围 |
| `meowList` | 第 35 行 | 猫咪说的话，随意增删 |
| `catImage` 宽高 130dp | floating_cat.xml | 猫咪大小 |

---

## ❓ 常见问题

**Q: 猫显示出来了但不动？**
A: 正常，它有时候会停下来"发呆"。等几秒就会继续走。

**Q: 猫被状态栏挡住了？**
A: 这是悬浮窗层级问题，可以在 params 里调整 y 坐标偏移。

**Q: 想让猫只在桌面显示，不在其他 App 上显示？**
A: 这需要监听前台 App 变化，可以在 Service 里加 `UsageStatsManager` 实现。

**Q: 能加更多动作吗？**
A: 当然！可以加睡觉动画、舔毛动画、追鼠标动画等。修改 `FloatingCatService.java` 即可。

---

## 📂 项目结构

```
FloatingCatApp/
├── build.gradle                    # 项目级构建配置
├── settings.gradle                 # 模块配置
├── gradle/wrapper/
│   └── gradle-wrapper.properties   # Gradle 版本
└── app/
    ├── build.gradle                # App 级构建配置
    └── src/main/
        ├── AndroidManifest.xml     # 权限 & 组件声明
        ├── java/com/lihuacat/
        │   ├── CatApp.java         # Application 入口
        │   ├── MainActivity.java   # 主界面（启动/关闭按钮）
        │   └── FloatingCatService.java  # ★ 核心：悬浮窗 + 所有猫咪行为
        └── res/
            ├── drawable/
            │   ├── cat_photo.png   # ★ 你家猫咪的图片
            │   └── bubble_bg.xml   # 说话气泡背景
            ├── layout/
            │   ├── activity_main.xml  # 主界面布局
            │   └── floating_cat.xml   # 悬浮猫布局
            └── values/
                ├── strings.xml     # 文字资源
                └── styles.xml     # 主题
```

---

## 🐾 祝你和桌面狸花猫愉快相处！

有任何问题随时问我，可以帮你加新功能：
- 更多动画（睡觉、伸懒腰、追蝴蝶）
- 喂食系统（点击喂食，猫会开心）
- 换装系统（给猫戴帽子、围巾）
- 声音互动（点击发出喵叫声）
- 手势互动（划屏猫会跟着看）
